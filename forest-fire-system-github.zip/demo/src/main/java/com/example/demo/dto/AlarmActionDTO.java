package com.example.demo.dto;

import lombok.Data;

@Data
public class AlarmActionDTO {
    private Long operatorId;
}
